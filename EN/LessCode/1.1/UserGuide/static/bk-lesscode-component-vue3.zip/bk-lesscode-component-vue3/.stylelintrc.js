module.exports = {
  defaultSeverity: 'error',
  extends: ['@blueking/stylelint-config-bk'],
}
