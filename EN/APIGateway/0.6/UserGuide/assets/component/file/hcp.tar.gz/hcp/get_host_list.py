# -*- coding: utf-8 -*-
"""
Copyright © 2012-2017 Tencent BlueKing. All Rights Reserved. 蓝鲸智云 版权所有
"""
import json

from django import forms

from common.forms import BaseComponentForm, TypeCheckField
from components.component import Component
from .toolkit import configs


# 组件类名，为组件模块名去掉下划线（_），各单词首字母大写拼接而成，如 get_host_list 组件类名应为 GetHostList
class GetHostList(Component):
    # 组件所属系统的系统名
    sys_name = configs.SYSTEM_NAME

    # Form 处理参数校验
    class Form(BaseComponentForm):
        bk_biz_id = forms.CharField(label="业务 ID", required=True)
        ip_list = TypeCheckField(label="主机 IP 地址", promise_type=list, required=False)

        # clean 方法返回的数据可通过组件的 form_data 属性获取
        def clean(self):
            return self.get_cleaned_data_when_exist(keys=['bk_biz_id', 'ip_list'])

    # 组件处理入口
    def handle(self):
        # 获取 Form clean 处理后的数据
        data = self.form_data

        # 请求系统后端接口
        try:
            response = self.outgoing.http_client.post(
                host=configs.host,
                path="/api/get_host_list/",
                data=json.dumps(data),
                headers={
                    # 将当前操作者添加到请求头
                    "Bk-Username": self.current_user.username,
                    # 将当前请求应用的 bk_app_code 添加到请求头
                    "Bk-App-Code": self.request.app_code,
                },
            )
        except Exception:
            # TODO: 需要删除，仅用于测试的假数据
            response = {
                "code": 0,
                "data": [
                    {
                        "inner_ip": "10.0.0.1",
                        "bk_cloud_id": 0,
                        "host_name": "just_for_test",
                        "maintainer": "admin",
                    },
                ]
            }

        # 对结果进行解析
        code = response["code"]
        if code == 0:
            result = {
                "result": True,
                "data": response["data"],
            }
        else:
            result = {
                "result": False,
                "message": response["message"]
            }

        # 设置组件返回结果，payload 为组件实际返回结果
        self.response.payload = result
