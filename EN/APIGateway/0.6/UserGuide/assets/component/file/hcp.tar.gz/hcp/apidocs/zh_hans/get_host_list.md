### 功能描述

查询主机列表

### 请求参数

{{ common_args_desc }}

#### 接口参数

| 字段  |  类型 | 必选   |  描述     |
|-----------|------------|--------|------------|
| app_id  |  int    | 是  | 业务ID  |
| ip_list |  array  | 否  | 主机IP地址，包含 ip 和 bk_cloud_id；其中，bk_cloud_id表示云区域ID  |

### 请求参数示例

```python
{
    "bk_app_code": "esb_test",
    "bk_app_secret": "xxx",
    "bk_token": "xxx-xxx-xxx-xxx-xxx",
    "bk_biz_id": 1,
    "ip_list": [
        {
            "ip": "10.0.0.1",
            "bk_cloud_id": 0
        },
        {
            "ip": "10.0.0.2"
            "bk_cloud_id": 0
        }
    ]
}
```

### 返回结果示例

```python
{
    "result": true,
    "code": 0,
    "message": "",
    "data": [
        {
            "inner_ip": "10.0.0.1",
            "bk_cloud_id": 0,
            "host_name": "db-1",
            "maintainer": "admin"
        },
        {
            "inner_ip": "10.0.0.2",
            "bk_cloud_id": 0,
            "host_name": "db-2",
            "maintainer": "admin"
        }
    ]
}
```
