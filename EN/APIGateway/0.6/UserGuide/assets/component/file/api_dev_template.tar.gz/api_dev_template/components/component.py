# -*- coding: utf-8 -*-
"""
Copyright © 2012-2018 Tencent BlueKing. All Rights Reserved. 蓝鲸智云 版权所有
"""
from esb.bkauth.models import AnonymousUser, User
from esb.component import BaseComponent


class Component(BaseComponent):
    def get_current_user(self):
        if not self.request.wsgi_request:
            return AnonymousUser()

        username = self.request.wsgi_request.g.get("current_user_username")
        if username:
            return User(username)
        else:
            return AnonymousUser()
