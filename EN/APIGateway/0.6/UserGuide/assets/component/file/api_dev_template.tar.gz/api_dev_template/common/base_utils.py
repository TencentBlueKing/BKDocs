# -*- coding: utf-8 -*-
"""
Copyright © 2012-2018 Tencent BlueKing. All Rights Reserved. 蓝鲸智云 版权所有
"""
from django.utils.encoding import force_text, smart_bytes, smart_text
from past.builtins import basestring


def str_bool(value):
    if isinstance(value, basestring):
        value = value.strip()
        if force_text(value.lower()) in ("0", "false"):
            return False
    return bool(value)


class FancyDict(dict):
    def __getattr__(self, key):
        try:
            return self[key]
        except KeyError as k:
            raise AttributeError(k)

    def __setattr__(self, key, value):
        self[key] = value

    def __delattr__(self, key):
        try:
            del self[key]
        except KeyError as k:
            raise AttributeError(k)


def smart_lower(value):
    result = [value[0].lower()]
    for c in value[1:]:
        if c >= "A" and c <= "Z":
            result.append("_")
        result.append(c.lower())
    return "".join(result)


def smart_str(s, encoding="utf-8"):
    return smart_bytes(s, encoding="utf-8", errors="ignore")


def smart_unicode(s, encoding="utf-8"):
    return smart_text(s, encoding="utf-8", errors="ignore")
