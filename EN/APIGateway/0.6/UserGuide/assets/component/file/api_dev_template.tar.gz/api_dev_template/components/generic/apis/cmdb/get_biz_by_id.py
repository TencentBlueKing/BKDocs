# -*- coding: utf-8 -*-
from django import forms

from common.constants import HTTP_METHOD
from common.forms import BaseComponentForm
from components.component import Component

from .toolkit import configs


class GetBizById(Component):
    suggest_method = HTTP_METHOD.GET
    label = u"根据业务ID查询业务"

    sys_name = configs.SYSTEM_NAME

    class Form(BaseComponentForm):
        bk_biz_id = forms.IntegerField(label="business id", required=True)

        def clean(self):
            data = self.cleaned_data
            return {
                "bk_biz_id": data["bk_biz_id"],
                "bk_supplier_account": "0",
            }

    def handle(self):
        # headers = {
        #     'HTTP_BLUEKING_SUPPLIER_ID': '0',
        #     'BK_USER': self.current_user.username,
        # }
        # self.response.payload = self.outgoing.http_client.get(
        #     host=configs.host,
        #     path='/api/get_biz_by_id/',
        #     params=self.form_data,
        #     headers=headers,
        # )
        self.response.payload = {"result": True, "data": self.form_data}
