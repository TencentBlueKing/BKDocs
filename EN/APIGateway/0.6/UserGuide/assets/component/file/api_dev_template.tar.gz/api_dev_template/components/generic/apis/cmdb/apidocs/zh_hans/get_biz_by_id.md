### 功能描述

根据业务ID查询业务

### 请求参数

{{ common_args_desc }}

#### 接口参数

| 字段     |  类型      | 必选   |  描述      |
|-----------|------------|--------|------------|
| bk_biz_id |  int     | 是     | 业务ID |

### 请求参数示例

```python
{
    "bk_app_code": "esb_test",
    "bk_app_secret": "xxx",
    "bk_token": "xxx",
    "bk_biz_id": 1
}
```

### 返回结果示例

```python

{
    "result": true,
    "code": 0,
    "message": "",
    "data": {
        "bk_biz_id": 1,
        "bk_biz_name": "test",
        "bk_supplier_account": "0"
    }
}
```
