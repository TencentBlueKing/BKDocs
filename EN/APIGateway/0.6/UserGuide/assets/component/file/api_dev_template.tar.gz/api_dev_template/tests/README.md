python manage.py test --keepdb tests.components.apis.test_cmdb.TestCMDB.test_get_biz_by_id
