# -*- coding: utf-8 -*-
from tests.utils.http_client import HttpClient


http_client_dev = HttpClient(
    host='http://127.0.0.1:8000/',
    bk_app_code='esb_test',
    bk_app_secret='xxx',
)

http_client_prod = HttpClient(
    host='http://paas.domain.com',
    url_prefix='/api',
    bk_app_code='',
    bk_app_secret='',
)
