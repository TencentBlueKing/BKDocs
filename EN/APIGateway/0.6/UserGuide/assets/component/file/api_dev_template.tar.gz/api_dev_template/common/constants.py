# -*- coding: utf-8 -*-
"""
Copyright © 2012-2018 Tencent BlueKing. All Rights Reserved. 蓝鲸智云 版权所有
"""
from common.base_utils import FancyDict

API_TYPE_OP = "operate"
API_TYPE_Q = "query"


HTTP_METHOD = FancyDict(
    (
        ("GET", "GET"),
        ("POST", "POST"),
    )
)
